import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const $=id=>document.getElementById(id);
const renderer=new THREE.WebGLRenderer({canvas:$('game'),antialias:false,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.35));renderer.setSize(innerWidth,innerHeight);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;
const scene=new THREE.Scene();scene.background=new THREE.Color(0x91adbf);scene.fog=new THREE.Fog(0x91adbf,85,340);
const camera=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,.1,700);
scene.add(new THREE.HemisphereLight(0xdceeff,0x34403b,1.8));
const sun=new THREE.DirectionalLight(0xffe0ad,2.1);sun.position.set(-50,70,30);scene.add(sun);
const mat=(c,r=.8,m=0)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m});
const M={road:mat(0x303740),side:mat(0x727980),grass:mat(0x4c6455),line:new THREE.MeshBasicMaterial({color:0xe3e4d9}),building:[0x66717b,0x858b8e,0x485563,0x9b9a8d,0x3f4c58,0x717c85].map(c=>mat(c)),glass:mat(0x243a49,.25,.35),dark:mat(0x151c24,.35,.35),tire:mat(0x101215),window:mat(0x152c3c,.22,.25),lamp:new THREE.MeshBasicMaterial({color:0xffe7a8}),lime:new THREE.MeshBasicMaterial({color:0xd8ff43}),red:new THREE.MeshBasicMaterial({color:0xff3535}),amber:new THREE.MeshBasicMaterial({color:0xffc43b}),green:new THREE.MeshBasicMaterial({color:0x36ef93}),off:new THREE.MeshBasicMaterial({color:0x242a30})};
const box=new THREE.BoxGeometry(1,1,1);
function cube(parent,material,x,y,z,sx,sy,sz){let o=new THREE.Mesh(box,material);o.position.set(x,y,z);o.scale.set(sx,sy,sz);parent.add(o);return o}
function group(){return new THREE.Group()}
const world=group();scene.add(world);
cube(world,M.grass,0,-.5,-110,360,1,520);
cube(world,M.road,0,-.12,-110,20,.22,520);
for(const x of [-7.8,-3.9,0,3.9,7.8]) for(let z=0;z>-510;z-=11) cube(world,M.line,x,.005,z,.12,.025,4.5);
for(const x of [-10.1,10.1])cube(world,M.side,x,-.01,-110,1.1,.3,520);

// Procedural grid city blocks on both sides of a boulevard; scenery scrolls in segments.
const blocks=[];
for(let side of [-1,1]){
 for(let z=15;z>-510;z-=23){
  const h=10+Math.random()*30,w=7+Math.random()*10,d=10+Math.random()*10,x=side*(17+Math.random()*10);
  const b=cube(world,M.building[Math.floor(Math.random()*M.building.length)],x,h/2,z,w,h,d);b.material=b.material.clone();
  const floors=Math.max(2,Math.floor(h/2.7));
  for(let f=1;f<floors;f++)for(let q=-1;q<=1;q++){
   if(Math.random()>.2)cube(world,Math.random()>.8?M.lime:M.glass,x+q*w*.25,h*(f/floors)-h/2+.1,z+d/2+.03,w*.11,.55,.07);
  }
  if(Math.random()>.72)cube(world,M.dark,x,h+.35,z,w*.4,.7,d*.35);
 }
 for(let z=0;z>-500;z-=27){
  const x=side*(12.3+Math.random()*1.4);
  cube(world,mat(0x4d463a),x,1,z,.3,2,.3);
  const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(1.4,0),mat([0x315947,0x45674e,0x536d4e][Math.floor(Math.random()*3)],1));crown.position.set(x,2.5,z);world.add(crown);
  cube(world,mat(0x333b44,.45,.6),side*10.7,2.2,z,.11,4.4,.11);cube(world,mat(0x333b44,.45,.6),side*10.3,4.3,z,.8,.1,.1);cube(world,M.lamp,side*10,4.2,z,.25,.08,.2);
 }
}
// Intersections and traffic signals at multiple city blocks.
const signals=[];
for(let z=-70;z>-480;z-=95){
 cube(world,M.road,0,-.105,z,35,.035,16);
 for(let x of [-9,9]){
  cube(world,mat(0x282f37),x,3.2,z,.14,6.4,.14);
  cube(world,mat(0x171d24),x,5.2,z,.65,1.5,.4);
  const bulbs=[];
  for(let i=0;i<3;i++){let bulb=cube(world,[M.red,M.amber,M.green][i],x,5.63-i*.42,z+.22,.2,.2,.06);bulbs.push(bulb)}
  signals.push({bulbs,offset:Math.random()*12});
 }
}
const carSpecs=[
 {id:'nightfall',name:'NIGHTFALL S',desc:'BALANCED STREET COUPE',color:0xd8ff43,max:39,accel:20,handling:1},
 {id:'scarlet',name:'SCARLET GT',desc:'HIGH SPEED · SHARP HANDLING',color:0xe94b4b,max:45,accel:18,handling:1.18},
 {id:'azure',name:'AZURE R',desc:'QUICK LAUNCH · LIGHT CHASSIS',color:0x4d9be8,max:40,accel:24,handling:1.28},
 {id:'phantom',name:'PHANTOM X',desc:'HEAVY · HIGH TOP SPEED',color:0xb2b9c3,max:48,accel:17,handling:.86}
];
function makeCar(spec){
 const g=group(),body=mat(spec.color,.27,.48);
 cube(g,body,0,.62,0,1.85,.5,3.5);cube(g,M.window,0,1.02,-.13,1.35,.53,1.55);cube(g,body,0,.9,1.12,1.62,.22,.7);cube(g,M.dark,0,.38,0,1.92,.16,3.3);
 for(let x of [-.96,.96])for(let z of [-1.08,1.08]){let t=new THREE.Mesh(new THREE.CylinderGeometry(.37,.37,.23,12),M.tire);t.rotation.z=Math.PI/2;t.position.set(x,.36,z);g.add(t)}
 for(let x of [-.58,.58]){cube(g,M.lamp,x,.67,-1.77,.34,.15,.04);cube(g,M.red,x,.66,1.77,.3,.15,.04)}
 const flame=cube(g,new THREE.MeshBasicMaterial({color:0x38dcff}),0,.34,1.82,.42,.09,.27);flame.visible=false;g.userData.flame=flame;g.userData.spec=spec;return g;
}
let save={credits:1250,rep:1,selected:'nightfall'};
try{save={...save,...JSON.parse(localStorage.getItem('streetRivalsV1')||'{}')}}catch{}
const saveNow=()=>localStorage.setItem('streetRivalsV1',JSON.stringify(save));
let selected=carSpecs.find(c=>c.id===save.selected)||carSpecs[0];
let player=makeCar(selected);player.position.set(0,0,4);scene.add(player);
function selectCar(spec){selected=spec;save.selected=spec.id;saveNow();scene.remove(player);player=makeCar(spec);player.position.set(0,0,4);scene.add(player);renderGarage()}
function renderGarage(){$('car-list').innerHTML='';for(const c of carSpecs){const b=document.createElement('button');b.className='car-option'+(c.id===selected.id?' selected':'');b.innerHTML=`<span class="car-icon" style="background:#${c.color.toString(16).padStart(6,'0')}"></span><span><b>${c.name}</b><small>${c.desc}</small></span><strong>${c.id===selected.id?'SELECTED':'SELECT'}</strong>`;b.onclick=()=>selectCar(c);$('car-list').appendChild(b)}}
renderGarage();function wallet(){$('credits').textContent=save.credits.toLocaleString();$('rep').textContent=String(save.rep).padStart(2,'0')}wallet();

const traffic=[];const trafficColors=[0xd6dce0,0xc54d42,0x4c7aa8,0x242d38,0xd6a24a,0x527866,0x7770a5];
function addTraffic(z,lane){const spec={color:trafficColors[Math.floor(Math.random()*trafficColors.length)],max:18,accel:8,handling:1};const c=makeCar(spec);c.scale.setScalar(.82);c.position.set(lane,0,z);c.userData.speed=8+Math.random()*14;c.userData.lane=lane;scene.add(c);traffic.push(c)}
for(let i=0;i<24;i++)addTraffic(-20-i*18,[-7.8,-3.9,0,3.9,7.8][Math.floor(Math.random()*5)]);

const audio={ctx:null,osc:null,osc2:null,gain:null,filter:null,enabled:true};
function startAudio(){
 if(audio.ctx){audio.ctx.resume();return}
 const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
 audio.ctx=new C();audio.osc=audio.ctx.createOscillator();audio.osc2=audio.ctx.createOscillator();audio.gain=audio.ctx.createGain();audio.filter=audio.ctx.createBiquadFilter();
 audio.osc.type='sawtooth';audio.osc2.type='triangle';audio.filter.type='lowpass';audio.filter.frequency.value=380;
 const mix=audio.ctx.createGain();mix.gain.value=.28;audio.osc.connect(mix);audio.osc2.connect(mix);mix.connect(audio.filter);audio.filter.connect(audio.gain);audio.gain.gain.value=0;audio.gain.connect(audio.ctx.destination);audio.osc.start();audio.osc2.start();
}
function audioUpdate(){if(!audio.ctx||!audio.enabled)return;const t=audio.ctx.currentTime;const rpm=75+state.speed*6+(state.boost?180:0);audio.osc.frequency.setTargetAtTime(rpm,t,.08);audio.osc2.frequency.setTargetAtTime(rpm*.503,t,.08);audio.filter.frequency.setTargetAtTime(260+state.speed*45,t,.1);audio.gain.gain.setTargetAtTime(state.mode==='drive'?.045+state.speed/650:0,t,.12)}
$('audio').onclick=()=>{audio.enabled=!audio.enabled;$('audio').textContent=audio.enabled?'♫ ON':'♫ OFF';if(audio.enabled)startAudio();else if(audio.gain&&audio.ctx)audio.gain.gain.setTargetAtTime(0,audio.ctx.currentTime,.05)};

const state={mode:'menu',event:'free',speed:0,distance:0,near:0,elapsed:0,timeLeft:0,checkpoints:0,boost:false};
const held=new Set();function hold(id,key){const el=$(id);const down=e=>{e.preventDefault();held.add(key);if(key==='gas')startAudio()};const up=e=>{e.preventDefault();held.delete(key)};el.addEventListener('pointerdown',down);['pointerup','pointercancel','pointerleave'].forEach(ev=>el.addEventListener(ev,up))}
hold('left','left');hold('right','right');hold('gas','gas');hold('brake','brake');hold('nitro','nitro');
addEventListener('keydown',e=>{const map={ArrowLeft:'left',a:'left',ArrowRight:'right',d:'right',ArrowUp:'gas',w:'gas',ArrowDown:'brake',s:'brake',Shift:'nitro'};if(map[e.key]){held.add(map[e.key]);if(map[e.key]==='gas')startAudio();e.preventDefault()}if(e.key==='Escape'&&state.mode==='drive')pause()});
addEventListener('keyup',e=>{const map={ArrowLeft:'left',a:'left',ArrowRight:'right',d:'right',ArrowUp:'gas',w:'gas',ArrowDown:'brake',s:'brake',Shift:'nitro'};if(map[e.key])held.delete(map[e.key])});
const screenIds=['home','garage','events','pause','results'];function show(id){screenIds.forEach(s=>$(s).classList.toggle('hidden',s!==id));$('hud').classList.toggle('hidden',state.mode!=='drive')}
function toast(t){const el=$('toast');el.textContent=t;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),1450)}
function landscape(){try{if(document.documentElement.requestFullscreen)document.documentElement.requestFullscreen();if(screen.orientation?.lock)screen.orientation.lock('landscape')}catch{}}
function resetTraffic(){traffic.forEach((c,i)=>{c.position.z=-22-i*18;c.position.x=[-7.8,-3.9,0,3.9,7.8][Math.floor(Math.random()*5)];c.userData.speed=8+Math.random()*14})}
function beginEvent(type){state.mode='drive';state.event=type;state.speed=0;state.distance=0;state.near=0;state.elapsed=0;state.checkpoints=0;state.timeLeft=type==='sprint'?75:type==='survival'?60:90;player.position.set(0,0,4);resetTraffic();const names={free:'FREE DRIVE',sprint:'BOULEVARD SPRINT',checkpoint:'CHECKPOINT RUN',survival:'TRAFFIC SURVIVAL'};const goals={free:'EXPLORE THE CITY',sprint:'REACH 1.5 KM',checkpoint:'FIND 5 CHECKPOINTS',survival:'SURVIVE 60 SECONDS'};$('event-name').textContent=names[type];$('objective').textContent=goals[type];$('objective-bar').style.width='0%';show(null);$('hud').classList.remove('hidden');landscape();startAudio()}
function pause(){if(state.mode==='drive'){state.mode='pause';show('pause')}}
function finish(won){state.mode='results';const reward=won?({free:Math.floor(100+state.distance*.04+state.near*25),sprint:350+state.near*15,checkpoint:500+state.near*20,survival:450+state.near*15}[state.event]):Math.floor(state.distance*.02);save.credits+=reward;if(won)save.rep=Math.min(99,save.rep+1);saveNow();wallet();$('result-title').innerHTML=won?'NICE <em>RUN.</em>':'RUN <em>OVER.</em>';$('result-distance').textContent=(state.distance/1000).toFixed(2)+' km';$('result-near').textContent=state.near;$('result-reward').textContent='+'+reward+' CR';show('results')}
$('play').onclick=()=>beginEvent('free');$('open-garage').onclick=()=>{state.mode='garage';renderGarage();show('garage')};$('open-events').onclick=()=>{state.mode='events';show('events')};
document.querySelectorAll('[data-home]').forEach(b=>b.onclick=()=>{state.mode='menu';show('home')});
document.querySelectorAll('[data-event]').forEach(b=>b.onclick=()=>beginEvent(b.dataset.event));
$('pause-btn').onclick=pause;$('resume').onclick=()=>{state.mode='drive';show(null)};$('end-run').onclick=()=>finish(false);$('retry').onclick=()=>beginEvent(state.event);

let checkpointMeshes=[];
function clearCheckpoints(){checkpointMeshes.forEach(m=>scene.remove(m));checkpointMeshes=[]}
function addCheckpoint(z){const ring=new THREE.Mesh(new THREE.TorusGeometry(4,.16,8,32),new THREE.MeshBasicMaterial({color:0xd8ff43}));ring.position.set(0,2.2,z);scene.add(ring);checkpointMeshes.push(ring)}
function update(dt){
 if(state.mode==='drive'){
  state.elapsed+=dt;if(state.event!=='free')state.timeLeft=Math.max(0,state.timeLeft-dt);
  const spec=selected,gas=held.has('gas'),brake=held.has('brake'),nitro=held.has('nitro');state.boost=nitro&&gas;
  state.speed+=((gas?spec.accel:-4.2)+(state.boost?22:0))*dt;if(brake)state.speed-=33*dt;state.speed=THREE.MathUtils.clamp(state.speed,0,spec.max+(state.boost?12:0));
  const steer=(held.has('left')?-1:0)+(held.has('right')?1:0);player.position.x+=steer*dt*(3.5+state.speed*.105)*spec.handling;player.position.x=THREE.MathUtils.clamp(player.position.x,-8.4,8.4);player.rotation.z=-steer*.075;player.rotation.y=-steer*.02;player.userData.flame.visible=state.boost;
  state.distance+=state.speed*dt;
  // City and traffic flow toward the player to simulate an extended road without loading a giant world.
  world.position.z=(world.position.z+state.speed*.46*dt)%23;
  for(const c of traffic){
   c.position.z+=(state.speed*.45-c.userData.speed)*dt;
   if(c.position.z>14){c.position.z=-430-Math.random()*70;c.position.x=[-7.8,-3.9,0,3.9,7.8][Math.floor(Math.random()*5)];c.userData.speed=8+Math.random()*14}
   const dx=Math.abs(c.position.x-player.position.x),dz=Math.abs(c.position.z-player.position.z);
   if(dx<1.65&&dz<2.5&&state.speed>5){state.speed*=.78;c.position.z-=7;toast('TRAFFIC HIT · SPEED LOST')}
   else if(dx<2.15&&dz<4.5&&dz>2.6&&state.speed>24&&!c.userData.counted){state.near++;c.userData.counted=true;setTimeout(()=>c.userData.counted=false,1200)}
  }
  // Signal cycle: red 0-5s, green 5-10s, amber 10-12s; cosmetic traffic control at crossings.
  signals.forEach(s=>{const t=(state.elapsed+s.offset)%12;const active=t<5?0:t<10?2:1;s.bulbs.forEach((b,i)=>b.material=i===active?[M.red,M.amber,M.green][i]:M.off)});
  // Traffic checkpoint markers are generated ahead and collected when crossed.
  if(state.event==='checkpoint'){
   if(checkpointMeshes.length<5-state.checkpoints){addCheckpoint(-85-state.checkpoints*65)}
   const cp=checkpointMeshes[0];if(cp){cp.position.z+=state.speed*.46*dt;if(cp.position.z>player.position.z-1){scene.remove(cp);checkpointMeshes.shift();state.checkpoints++;toast('CHECKPOINT '+state.checkpoints+'/5')}}
  }
  camera.position.lerp(new THREE.Vector3(player.position.x*.45,4.6,10.8),1-Math.exp(-dt*3.2));camera.lookAt(player.position.x*.25,1,-12);
  $('speed').textContent=String(Math.round(state.speed*3.6)).padStart(3,'0');$('gear').textContent=String(Math.max(1,Math.min(6,Math.floor(state.speed/8)+1)));$('near').textContent=state.near;$('dist').textContent=(state.distance/1000).toFixed(2)+' km';
  $('timer').textContent=state.event==='free'?'FREE DRIVE':`TIME ${String(Math.floor(state.timeLeft/60)).padStart(2,'0')}:${String(Math.floor(state.timeLeft%60)).padStart(2,'0')}`;
  const progress=state.event==='sprint'?state.distance/1500:state.event==='checkpoint'?state.checkpoints/5:state.event==='survival'?state.elapsed/60:state.distance/5000;
  $('objective-bar').style.width=Math.min(100,progress*100)+'%';
  if(state.event==='sprint'&&state.distance>=1500)finish(true);
  else if(state.event==='checkpoint'&&state.checkpoints>=5)finish(true);
  else if(state.event==='survival'&&state.timeLeft<=0)finish(true);
  else if(state.event!=='free'&&state.timeLeft<=0)finish(false);
 }else{
  player.rotation.y=Math.sin(performance.now()*.00035)*.055;camera.position.lerp(new THREE.Vector3(0,5.2,10.8),.025);camera.lookAt(0,1,-2);
 }
 audioUpdate();
}
let last=performance.now();
function resize(){renderer.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix()}
addEventListener('resize',resize);
function animate(now){requestAnimationFrame(animate);const dt=Math.min((now-last)/1000,.04);last=now;update(dt);renderer.render(scene,camera)}
camera.position.set(0,5.2,10.8);camera.lookAt(0,1,-2);show('home');animate(last);
