# Street Rivals: Open City — Mobile Racing Upgrade

## What this build adds
- Extended boulevard/city blocks with procedural buildings, roadside trees and streetlights.
- Traffic lights with a rotating red/amber/green signal cycle.
- Four selectable cars with different speed, acceleration and handling.
- Synthesized engine audio using Web Audio (audio begins after player interaction).
- Race events: Boulevard Sprint, Checkpoint Run, Traffic Survival, Free Drive.
- Credits/reputation, near-miss scoring, results screen, landscape-oriented PWA metadata.
- Basic service-worker shell cache and Capacitor wrapper configuration.

## Android phone playtest
This is a browser/PWA build and requires an HTTPS host because it uses ES modules and Three.js from a CDN.
1. Upload the project to a GitHub repository or static HTTPS host.
2. Open its hosted `index.html` in Chrome on Android.
3. Tap Enter the City and rotate to landscape.
4. Controls: left/right, ACCEL, BRAKE, N₂O. Desktop: A/D or arrows, W/Up, S/Down, Shift.
5. Tap ♫ to mute/unmute engine sound.

## Build an Android APK using GitHub Actions (recommended if you only have a phone)
1. Create a GitHub repository and upload all project files, including `.github/workflows/android-debug-apk.yml`.
2. In GitHub, open **Actions** and run **Build Android Debug APK** (or push to `main`).
3. Wait for the workflow to finish. Download the `street-rivals-debug-apk` artifact from the run page.
4. Install the APK on your Android phone after enabling installation from that source. A debug APK is for testing, not a Play Store release.

Alternatively, on a computer with Node.js, Java 17 and Android SDK:
```
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

## Commercial release checklist — not yet complete
This is an upgraded playable vertical slice, not a certified production-ready game. Before selling or publishing:
- Test frame rate, heat, battery, crashes and controls on low-end Android devices.
- Replace procedural placeholder car/city art with optimized original/licensed assets.
- Add real recorded engine/traffic/UI audio, sound controls and accessibility settings.
- Improve traffic AI, intersections, lane rules, collisions, minimap and city navigation.
- Add robust checkpoint logic, event balancing, pause/resume lifecycle, save migration and QA.
- Decide whether accounts, cloud saves, multiplayer, telemetry or ads are needed; add privacy/consent and secure backend only if used.
- Add store icon, screenshots, trailer, privacy policy, terms, signing key and Android App Bundle (AAB) for Google Play.
- Review third-party licenses and test all target API requirements before release.

## Important technical notes
- Three.js is loaded from jsDelivr; a live internet connection is needed for the 3D engine unless you vendor and audit the library locally.
- Browser orientation locking is best-effort; Android browser policy can require fullscreen/user gesture.
- This project does not include online multiplayer or a compiled APK artifact yet.
